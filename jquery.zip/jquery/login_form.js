$(document).ready(() => {
  // $("h1").text("hello");
  // $("#a").text("hello 1");
  // $("a").text("hello 2");
  // const v = $("b").text();
  // alert(v);
  // -==========================
  // $("#btn1").click(() => {
  //   let t = $("#t1").val();
  //   $("#t2").val(t);
  // });
  // $("#t1").keyup(() => {
  //   const t = $("#t1").val();
  //   $("#t2").val(t);
  // });
  // -==========================
  // $("#t3").click(() => {
  //   $("#t3").attr("type", "button");
  // });
  // -==========================
  $("#t3").keyup(() => {
    const color = $("#t3").val();
    $("body").css("background", color);
    $("h1").text(color);
  });
});
