import { useDispatch, useSelector } from "react-redux"; //hooks
import { changeName, changeCity } from "./MyRedux/faculty_slice"; //actions

function ReduxFetchData() {
  const { data } = useSelector((state) => state);
  console.log("data", data);
  const dispatch = useDispatch();

  return (
    <div>
      {data.name}
      <button
        onClick={() => {
          dispatch(changeName({ name: "alok" }));
        }}
      >
        Change
      </button>
      <button
        onClick={() => {
          dispatch(changeCity({ city: "sagar" }));
        }}
      >
        Change City
      </button>
    </div>
  );
}

export default ReduxFetchData;
