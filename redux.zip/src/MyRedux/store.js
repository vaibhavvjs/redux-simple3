import { configureStore } from "@reduxjs/toolkit";
import faculty_slice from "./faculty_slice";

const reducer = { data: faculty_slice };

const profileStore = configureStore({ reducer });
export default profileStore;
