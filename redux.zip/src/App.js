import { Provider } from "react-redux";
import store from "./MyRedux/store";
import ReduxFetchData from "./ReduxFetchData";
const App = () => {
  return (
    <Provider store={store}>
      <ReduxFetchData />
    </Provider>
  );
};
export default App;
