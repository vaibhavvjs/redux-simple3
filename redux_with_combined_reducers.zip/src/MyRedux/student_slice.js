import { createSlice } from "@reduxjs/toolkit";

const initialState = { name: "dhruv", city: "sagar", fees: 100 };

const slice = {
  name: "student",
  initialState,
  reducers: {
    changeName: (initialState, data) => {
      const { name } = data.payload;
      initialState["name"] = name;
    },
    changeCity: (initialState, data) => {
      const { city } = data.payload;
      initialState["city"] = city;
    },
  },
};

const slice_obj = createSlice(slice);

export const { changeName, changeCity } = slice_obj.actions;
export default slice_obj.reducer;
