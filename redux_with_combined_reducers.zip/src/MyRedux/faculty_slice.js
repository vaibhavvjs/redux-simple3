import { createSlice } from "@reduxjs/toolkit";

const initialState = { name: "vaibhav", city: "bhopal", salary: 100 };

const slice = {
  name: "faculty",
  initialState,
  reducers: {
    changeName: (initialState, data) => {
      const { name } = data.payload;
      initialState["name"] = name;
    },
    changeCity: (initialState, data) => {
      console.log("ssss", data);
      const { city } = data.payload;
      initialState["city"] = city;
    },
  },
};

const slice_obj = createSlice(slice);

export const { changeName, changeCity } = slice_obj.actions;
const faculty_slice = slice_obj.reducer;
export default faculty_slice;
