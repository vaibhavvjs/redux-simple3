import { configureStore, combineReducers } from "@reduxjs/toolkit";
import faculty from "./faculty_slice";
import student from "./student_slice";

// const reducers = { faculty_slice };

const reducers = { faculty, student };

const reducer = combineReducers(reducers);

const profileStore = configureStore({ reducer });
export default profileStore;
