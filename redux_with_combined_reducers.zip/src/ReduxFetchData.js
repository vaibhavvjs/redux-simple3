import { useDispatch, useSelector } from "react-redux"; //hooks
import {
  changeName as changeFacultyName,
  changeCity as changeFacultyCity,
} from "./MyRedux/faculty_slice"; //actions

import {
  changeName as changeStudentName,
  changeCity as changeStudentCity,
} from "./MyRedux/student_slice"; //actions

function ReduxFetchData() {
  const state = useSelector((state) => state);
  console.log("state", state);
  const { student, faculty } = state;
  const dispatch = useDispatch();
  const obj = { name: "ankur" };
  const obj2 = { name: "amit" };
  const { name } = obj;
  const { name: abcd } = obj2;

  return (
    <div>
      {abcd}
      <button
        onClick={() => {
          dispatch(changeFacultyName({ name: "alok" }));
        }}
      >
        Change
      </button>
      <button
        onClick={() => {
          dispatch(changeStudentCity({ city: "indore" }));
        }}
      >
        Change City
      </button>
    </div>
  );
}

export default ReduxFetchData;
